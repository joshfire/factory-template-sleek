define([],
function() {
	return {
		"DEFAULT": "en",
		"AVAILABLE": [
			"en",
			"fr"
		]
	};
});